#!/bin/bash

python3 code/RPI_HMI_v1.0.py