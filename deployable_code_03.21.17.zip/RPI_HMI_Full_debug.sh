#!/bin/bash

python3 code/RPI_HMI_FULL_DEBUG.py