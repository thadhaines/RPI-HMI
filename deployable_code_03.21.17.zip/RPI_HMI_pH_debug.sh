#!/bin/bash

python3 code/RPI_HMI_pH_DEBUG.py